from csv import reader  # lib to read csv

# Assuming selling is increase in my balance
# buying is reduction of my balance
# idea 1
# -ve is you selling your share
# +ve is you buying your share


def profitCalculation(docLink, current_position):
    myBalance = 0
    with open(docLink, "r") as read_csv:
        csv_reader = reader(read_csv)  # converts it to a iterable format
        next(csv_reader, None)  # to ignore header
        for trade in csv_reader:
            tradeVolume = int(trade[2])
            if tradeVolume < 0:  # if we are selling
                position_size = (
                    min(abs(tradeVolume), current_position)
                    * -1  # -1 because sell reduces the number of positions we have
                )  # We sell 0, if we have 0 positions
            else:  # if we are buying
                position_size = min(
                    tradeVolume, 100000 - current_position
                )  # We can't own more than 100'000 positions
            current_position += position_size
            myBalance -= position_size * float(
                trade[1]
            )  # Increase in position means buy, hence reduce in balance, and vice versa
        print("My final profit :", "{0:.2f}".format(myBalance))
        print("My final position :", current_position)


# Assuming I have 100'000 position in the beginning
profitCalculation("data_v2.csv", 100000)
